/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proje;

import java.util.Scanner;

/**
 *
 * @author niranuyanik
 */
public class Proje {
   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Galaksi galaksi = new Galaksi();

        // Galaksiye cisimler ekleniyor
        galaksi.cisimEkle(new YasayabilirGezegen("Dünya", 10, 20, 100));
        galaksi.cisimEkle(new GazDevi("Jüpiter", 30, 40, 50));
        galaksi.cisimEkle(new Karadelik("Karadelik-1", 50, 60, 75.0));
        galaksi.cisimEkle(new YasayabilirGezegen("Mars", 70, 80, 70));
        galaksi.cisimEkle(new GazDevi("Satürn", 90, 10, 30));

        UzayKesifAraci arac = new UzayKesifAraci(100, 50);

        while (arac.getYakitSeviyesi() > 0) {
            System.out.println("\n--- Galaksi Haritası ---");
            galaksi.cisimleriYazdir();

            System.out.println("\n--- Uzay Keşif Aracı Durumu ---");
            arac.durumYazdir();

            System.out.println("Bir cisim seçin (isim yazarak): ");
            String secim = scanner.nextLine();

            boolean bulundu = false;
            Gezegen[] gezegenler = galaksi.gezegenleriGetir();

            for (int i = 0; i < gezegenler.length; i++) {
                if (gezegenler[i] != null && gezegenler[i].getIsim().equals(secim)) {
                    bulundu = true;
                    gezegenler[i].kaynakTopla(arac);
                    break;
                }
            }

            if (!bulundu) {
                Cisim[] cisimler = galaksi.getCisimler();
                int cisimSayisi = galaksi.getCisimSayisi();
                for (int i = 0; i < cisimSayisi; i++) {
                    if (cisimler[i] != null && cisimler[i].getIsim().equals(secim) && cisimler[i] instanceof Karadelik) {
                        Karadelik karadelik = (Karadelik) cisimler[i];
                        karadelik.karadelikEtkilesimi(arac, gezegenler);
                        bulundu = true;
                        break;
                    }
                }
            }

            if (!bulundu) {
                System.out.println("Hatalı seçim yaptınız.");
            }
        }
    }
}

/* public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Galaksi galaksi = new Galaksi();

        // Galaksiye cisimler ekleniyor
        galaksi.cisimEkle(new YasayabilirGezegen("Dünya", 10, 20, 100));
        galaksi.cisimEkle(new GazDevi("Jüpiter", 30, 40, 50));
        galaksi.cisimEkle(new Karadelik("Karadelik-1", 50, 60, 75.0));
        galaksi.cisimEkle(new YasayabilirGezegen("Mars", 70, 80, 70));
        galaksi.cisimEkle(new GazDevi("Satürn", 90, 10, 30));

        UzayKesifAraci arac = new UzayKesifAraci(100, 50);

        while (arac.getYakitSeviyesi() > 0) {
            System.out.println("\n--- Galaksi Haritası ---");
            galaksi.cisimleriYazdir();

            System.out.println("\n--- Uzay Keşif Aracı Durumu ---");
            arac.durumYazdir();

            System.out.println("Bir cisim seçin (isim yazarak): ");
            String secim = scanner.nextLine();

            boolean bulundu = false;
            Gezegen[] gezegenler = galaksi.gezegenleriGetir();

            for (int i = 0; i < gezegenler.length; i++) {
                if (gezegenler[i] != null && gezegenler[i].getIsim().equals(secim)) {
                    bulundu = true;
                    gezegenler[i].kaynakTopla(arac);
                    break;
                }
            }

            if (!bulundu) {
                for (int i = 0; i < cisimSayisi; i++) {
                    if (cisimler[i] instanceof Karadelik && cisimler[i].getIsim().equals(secim)) {
                        ((Karadelik) cisimler[i]).karadelikEtkilesimi(arac, gezegenler);
                        bulundu = true;
                        break;
                    }
                }
            }

            if (!bulundu) {
                System.out.println("Hatalı seçim yaptınız.");
            }
        }
    }
} */
   /* public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Galaksi galaksi = new Galaksi();

        // Galaksiye cisimler ekleniyor
        galaksi.cisimEkle(new YasayabilirGezegen("Dünya", 10, 20, 100));
        galaksi.cisimEkle(new GazDevi("Jüpiter", 30, 40, 50));
        galaksi.cisimEkle(new Karadelik("Karadelik-1", 50, 60, 75.0));
        galaksi.cisimEkle(new YasayabilirGezegen("Mars", 70, 80, 70));
        galaksi.cisimEkle(new GazDevi("Satürn", 90, 10, 30));

        UzayKesifAraci arac = new UzayKesifAraci(100, 50);

        while (arac.getYakitSeviyesi() > 0) {
            System.out.println("\n--- Galaksi Haritası ---");
            galaksi.cisimleriYazdir();

            System.out.println("\n--- Uzay Keşif Aracı Durumu ---");
            arac.durumYazdir();

            System.out.println("Bir cisim seçin (isim yazarak): ");
            String secim = scanner.nextLine();

    boolean bulundu = false;
    for (int i = 0; i < galaksi.cisimleriGetir().length; i++) {
        Cisim cisim = galaksi.cisimleriGetir()[i];
        if (cisim.getIsim().equals(secim)) {
            bulundu = true;
            if (cisim instanceof Karadelik) {
                ((Karadelik) cisim).karadelikEtkilesimi(arac, galaksi.gezegenleriGetir());
            } else if (cisim instanceof Gezegen) {
                Gezegen gezegen = (Gezegen) cisim;
                gezegen.kaynakTopla(arac);
            }
            arac.yakitAzalt(10); // Her seçim için yakıt tüketimi
            break;
        }
    }

    if (!bulundu) {
        System.out.println("Geçersiz seçim. Tekrar deneyin.");
    }
}
        }
    
} */
   /* public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UzayKesifAraci arac = new UzayKesifAraci(100, 50);
        Gezegen gezegen = new Gezegen("Dünya", 10, 20, "Kaya");
        Karadelik karadelik = new Karadelik("Karadelik-1", 50, 70, 100.0);

        boolean devam = true;
        while (devam) {
            System.out.println("1. Gezegen'e git");
            System.out.println("2. Karadelik'e git");
            System.out.println("3. Çıkış");
            System.out.print("Seçiminiz: ");
            int secim = scanner.nextInt();

            switch (secim) {
                case 1:
                    arac.hareketEt(gezegen);
                    break;
                case 2:
                    arac.hareketEt(karadelik);
                    break;
                case 3:
                    System.out.println("Program sonlandırılıyor.");
                    devam = false;
                    break;
                default:
                    System.out.println("Geçersiz seçim, tekrar deneyin.");
            }
        }
        
    }
}*/
    
    /*   
        Scanner scanner = new Scanner(System.in);

        // Galaksi ve uzay keşif aracı oluştur
        Galaksi galaksi = new Galaksi(5); // 5 cisimli galaksi
        UzayKesifAraci arac = new UzayKesifAraci("Voyager", 100, 50); // Başlangıç özellikleri

        boolean cikis = false;

        // Menü döngüsü
        while (!cikis) {
            System.out.println("\n--- Uzay Keşif Oyunu ---");
            System.out.println("1. Uzay keşif aracının durumunu göster");
            System.out.println("2. Galaksideki cisimleri göster");
            System.out.println("3. Hedef bir cisme hareket et");
            System.out.println("4. Yakıt ikmali yap");
            System.out.println("5. Çıkış");
            System.out.print("Seçiminiz: ");

            int secim = scanner.nextInt();

            switch (secim) {
                case 1:
                    arac.durumGoster();
                    break;
                case 2:
                    galaksi.cisimleriYazdir();
                    break;
                case 3:
                    System.out.print("Hedef cismin indeksini girin (0-" + (galaksi.cisimlerUzunluk() - 1) + "): ");
                    int hedefIndex = scanner.nextInt();
                    if (hedefIndex >= 0 && hedefIndex < galaksi.cisimlerUzunluk()) {
                        Cisim hedef = galaksi.getCisim(hedefIndex);
                        arac.hareketEt(hedef.x, hedef.y);

                        if (hedef instanceof Gezegen) {
                            Gezegen gezegen = (Gezegen) hedef;
                            arac.kaynakTopla(gezegen);
                        }
                    } else {
                        System.out.println("Geçersiz indeks!");
                    }
                    break;
                case 4:
                    arac.yakitIkmali();
                    break;
                case 5:
                    cikis = true;
                    System.out.println("Oyun sonlandırıldı. İyi günler!");
                    break;
                default:
                    System.out.println("Geçersiz seçim! Lütfen tekrar deneyin.");
            }
        }


    }*/
    
        
    
    

