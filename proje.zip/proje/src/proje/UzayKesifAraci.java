/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proje;

/**
 *
 * @author niranuyanik
 */



class UzayKesifAraci {
    private int yakitSeviyesi;
    private int kapasite;
    private int mevcutKaynak;
    private int x;
    private int y;

    public UzayKesifAraci(int yakitSeviyesi, int kapasite) {
        this.yakitSeviyesi = yakitSeviyesi;
        this.kapasite = kapasite;
        this.mevcutKaynak = 0;
        this.x = 0;
        this.y = 0;
    }
     public int getYakitSeviyesi() {
        return yakitSeviyesi;
    }

    public int getKapasite() {
        return kapasite;
    }

    public int getMevcutKaynak() {
        return mevcutKaynak;
    }


    public void kaynakAzalt(int miktar) {
        mevcutKaynak -= miktar;
        if (mevcutKaynak < 0) mevcutKaynak = 0;
    }

    public void yakitAzalt(int miktar) {
        yakitSeviyesi -= miktar;
        if (yakitSeviyesi < 0) yakitSeviyesi = 0;
    }
      public void kaynakEkle(int miktar) {
        mevcutKaynak += miktar;
        if (mevcutKaynak > kapasite) mevcutKaynak = kapasite;
    }


    public void setKonum(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void durumYazdir() {
        System.out.println("Uzay Keşif Aracı Durumu:");
        System.out.println("Yakıt Seviyesi: " + yakitSeviyesi);
        System.out.println("Kaynak Miktarı: " + mevcutKaynak + "/" + kapasite);
        System.out.println("Konum: (" + x + ", " + y + ")");
    }
}

   /* class UzayKesifAraci {
    private String isim;
    private int x; // Mevcut X konumu
    private int y; // Mevcut Y konumu
    private double yakitSeviyesi;
    private double maksimumYakit;
    private double kapasite;
    private double mevcutKaynak;

    public UzayKesifAraci(String isim, double maksimumYakit, double kapasite) {
        this.isim = isim;
        this.x = 0;
        this.y = 0;
        this.yakitSeviyesi = maksimumYakit;
        this.maksimumYakit = maksimumYakit;
        this.kapasite = kapasite;
        this.mevcutKaynak = 0;
    }

    public void durumGoster() {
        System.out.println("Uzay Keşif Aracı: " + isim);
        System.out.println("Konum: (" + x + ", " + y + ")");
        System.out.println("Yakıt Seviyesi: " + yakitSeviyesi + "/" + maksimumYakit);
        System.out.println("Kapasite: " + mevcutKaynak + "/" + kapasite);
    }

    public void hareketEt(int hedefX, int hedefY) {
        double mesafe = Math.sqrt(Math.pow(hedefX - x, 2) + Math.pow(hedefY - y, 2));
        double gerekenYakit = mesafe * 0.5; // Her birim mesafe için 0.5 yakıt tüketimi

        if (gerekenYakit <= yakitSeviyesi) {
            x = hedefX;
            y = hedefY;
            yakitSeviyesi -= gerekenYakit;
            System.out.println("Uzay aracı yeni konuma hareket etti: (" + x + ", " + y + ")");
        } else {
            System.out.println("Yeterli yakıt yok! Lütfen yakıt ikmali yapın.");
        }
    }

    public void kaynakTopla(Gezegen gezegen) {
        if (gezegen != null && gezegen.getKaynakMiktari() > 0) {
            double toplanacakKaynak = Math.min(kapasite - mevcutKaynak, gezegen.getKaynakMiktari());
            mevcutKaynak += toplanacakKaynak;
            gezegen.ayarlaKaynakMiktari(gezegen.getKaynakMiktari() - toplanacakKaynak);
            System.out.println("Kaynak toplandı: " + toplanacakKaynak);
        } else {
            System.out.println("Toplanacak kaynak yok veya araç kapasitesi dolu!");
        }
    }

    public void yakitIkmali() {
        double gerekenYakit = maksimumYakit - yakitSeviyesi;
        yakitSeviyesi = maksimumYakit;
        System.out.println("Yakıt dolduruldu. Doldurulan miktar: " + gerekenYakit);
    } */



