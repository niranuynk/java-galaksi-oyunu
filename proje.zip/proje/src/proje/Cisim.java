/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proje;
 
/**
 *
 * @author niranuyanik
 */
abstract public class Cisim {
 protected String isim;
    protected int x;
    protected int y;

    public Cisim(String isim, int x, int y) {
        this.isim = isim;
        this.x = x;
        this.y = y;
    }

    public String getIsim() {
        return isim;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public abstract void yazdir();


/*abstract class Cisim {
    protected String isim;

    public Cisim(String isim) {
        this.isim = isim;
    }

    public String getIsim() {
        return isim;
    }

    public abstract void bilgiGoster();
}*/
}
