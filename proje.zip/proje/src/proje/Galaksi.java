/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proje;


class Galaksi {
  
    private Cisim[] cisimler;
    private int cisimSayisi;

    public Galaksi() {
        cisimler = new Cisim[100]; // Geleneksel dizi kullanımı
        cisimSayisi = 0;
    }

    public void cisimEkle(Cisim cisim) {
        if (cisimSayisi < cisimler.length) {
            cisimler[cisimSayisi++] = cisim;
        } else {
            System.out.println("Galaksi dolu, yeni cisim eklenemiyor.");
        }
    }

    public Gezegen[] gezegenleriGetir() {
        int sayac = 0;
        for (int i = 0; i < cisimSayisi; i++) {
            if ("Gezegen" == cisimler[i].getClass().getSuperclass().getSimpleName()) {
                sayac++;
            }
        }

        Gezegen[] gezegenler = new Gezegen[sayac];
        int index = 0;
        for (int i = 0; i < cisimSayisi; i++) {
            if ("Gezegen" == cisimler[i].getClass().getSuperclass().getSimpleName()) {
                gezegenler[index++] = (Gezegen) cisimler[i];
            }
        }

        return gezegenler;
    }

    public void cisimleriYazdir() {
        for (int i = 0; i < cisimSayisi; i++) {
            cisimler[i].yazdir();
        }
    }
}

    
    /* private Cisim[] cisimler;
    private int cisimSayisi;

    public Galaksi() {
        cisimler = new Cisim[100]; // Geleneksel dizi kullanımı
        cisimSayisi = 0;
    }

    public void cisimEkle(Cisim cisim) {
        if (cisimSayisi < cisimler.length) {
            cisimler[cisimSayisi++] = cisim;
        } else {
            System.out.println("Galaksi dolu, yeni cisim eklenemiyor.");
        }
    }

    public Gezegen[] gezegenleriGetir() {
        int sayac = 0;
        for (int i = 0; i < cisimSayisi; i++) {
            if ("Gezegen" == cisimler[i].getClass().getSuperclass().getSimpleName()) {
                sayac++;
            }
        }

        Gezegen[] gezegenler = new Gezegen[sayac];
        int index = 0;
        for (int i = 0; i < cisimSayisi; i++) {
            if ("Gezegen" == cisimler[i].getClass().getSuperclass().getSimpleName()) {
                gezegenler[index++] = (Gezegen) cisimler[i];
            }
        }

        return gezegenler;
    }

    public void cisimleriYazdir() {
        for (int i = 0; i < cisimSayisi; i++) {
            cisimler[i].yazdir();
        }
    } */



  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


