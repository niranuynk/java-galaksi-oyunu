/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proje;

/**
 *
 * @author niranuyanik
 */
class Karadelik extends Cisim {
    
    
    
    
    // Karadelik sınıfı

    private double cekimGucu;

    public Karadelik(String isim, int x, int y, double cekimGucu) {
        super(isim, x, y);
        this.cekimGucu = cekimGucu;
    }

    public void karadelikEtkilesimi(UzayKesifAraci arac, Gezegen[] gezegenler) {
        System.out.println(isim + " karadeliğine yaklaşıyorsunuz...");

        // Karadeliğin davranışı rastgele belirleniyor
        int mod = (int) (Math.random() * 2); // 0 veya 1

        if (mod == 1) {
            // Kaynak ve yakıt tüketme modu
            int tuketilenKaynak = 10;
            int tuketilenYakit = 5;

            arac.kaynakAzalt(tuketilenKaynak);
            arac.yakitAzalt(tuketilenYakit);

            System.out.println("Karadelik, geminizdeki " + tuketilenKaynak + " birim kaynağı ve " + tuketilenYakit + " birim yakıtı tüketti.");
        } else {
            // Ücretsiz mod
            System.out.println("Karadelik, geminizi ücretsiz bir şekilde ışınladı!");
        }

        // Rastgele bir gezegene ışınlama
        int rastgeleIndex = (int) (Math.random() * gezegenler.length);
        Gezegen hedefGezegen = gezegenler[rastgeleIndex];
        arac.setKonum(hedefGezegen.getX(), hedefGezegen.getY());

        System.out.println("Geminiz " + hedefGezegen.getIsim() + " gezegenine ışınlandı! Yeni konum: (" + hedefGezegen.getX() + ", " + hedefGezegen.getY() + ")");
    }

    @Override
    public void yazdir() {
        System.out.println("Karadelik: " + isim + ", Çekim Gücü: " + cekimGucu + ", Konum: (" + x + ", " + y + ")");
    }
}

// Uzay Keşif Aracı sınıfı

    /*private double cekimGucu;

    public Karadelik(String isim, int x, int y, double cekimGucu) {
        super(isim, x, y);
        this.cekimGucu = cekimGucu;
    }

    @Override
    public void yazdir() {
        System.out.println("Karadelik: " + isim + ", Çekim Gücü: " + cekimGucu + ", Konum: (" + x + ", " + y + ")");
    } */

