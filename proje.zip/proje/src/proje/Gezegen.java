/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proje;

/**
 *
 * @author niranuyanik
 */
class Gezegen extends Cisim {
    protected int kaynakMiktari;

    public Gezegen(String isim, int x, int y, int kaynakMiktari) {
        super(isim, x, y);
        this.kaynakMiktari = kaynakMiktari;
    }

    public int getKaynakMiktari() {
        return kaynakMiktari;
    }

    public int inisMaliyeti() {
        // Varsayılan bir iniş maliyeti değeri verin
        return 10;
    }

    public void kaynakTopla(UzayKesifAraci arac) {
        int kapasite = arac.getKapasite();
        int mevcutKaynak = arac.getMevcutKaynak();
        int toplanabilirKaynak = Math.min(kaynakMiktari, kapasite - mevcutKaynak);

        arac.kaynakEkle(toplanabilirKaynak);
        kaynakMiktari -= toplanabilirKaynak;

        System.out.println(isim + " gezegeninden " + toplanabilirKaynak + " birim kaynak toplandı.");
    }

    @Override
    public void yazdir() {
        System.out.println("Gezegen: " + isim + ", Konum: (" + x + ", " + y + "), Kaynak Miktarı: " + kaynakMiktari);
    }
}





/*class Gezegen extends Cisim {
    protected int kaynakMiktari;

    public Gezegen(String isim, int x, int y, int kaynakMiktari) {
        super(isim, x, y);
        this.kaynakMiktari = kaynakMiktari;
    }

    public int getKaynakMiktari() {
        return kaynakMiktari;
    }

    public abstract int inisMaliyeti();

    public void kaynakTopla(UzayKesifAraci arac) {
        int kapasite = arac.getKapasite();
        int mevcutKaynak = arac.getMevcutKaynak();
        int toplanabilirKaynak = Math.min(kaynakMiktari, kapasite - mevcutKaynak);

        arac.kaynakEkle(toplanabilirKaynak);
        kaynakMiktari -= toplanabilirKaynak;

        System.out.println(isim + " gezegeninden " + toplanabilirKaynak + " birim kaynak toplandı.");
    }

    @Override
    public void yazdir() {
        System.out.println("Gezegen: " + isim + ", Konum: (" + x + ", " + y + "), Kaynak Miktarı: " + kaynakMiktari);
    }
} */

    
    
    
    
   /* private String tur;

    public Gezegen(String isim, int x, int y, String tur) {
        super(isim, x, y);
        this.tur = tur;
    }

    @Override
    public void yazdir() {
        System.out.println("Gezegen: " + isim + ", Tür: " + tur + ", Konum: (" + x + ", " + y + ")");
    }*/


/*class Gezegen extends Cisim {
    private double kaynakMiktari;

    // Constructor
    public Gezegen(String isim, double kaynakMiktari) {
        super(isim);
        this.kaynakMiktari = kaynakMiktari;
    }

    // Kaynak miktarını döndüren getter metodu
    public double getKaynakMiktari() {
        return kaynakMiktari;
    }

    // Kaynak toplama metodu
    public void kaynakTopla(UzayKesifAraci arac) {
        if (kaynakMiktari > 0) {
            arac.kaynakEkle(kaynakMiktari);

            // Pozitif kaynak miktarı için mesaj oluştur ve harf harf yazdır
            System.out.println(isim + " gezegeninden " + kaynakMiktari + " birim kaynak toplandı.");
            for (int i = 0; i < mesaj.length(); i++) {
                System.out.print(mesaj.charAt(i)); // Harf harf yazdır
            }
            System.out.println(); // Yeni satıra geç

            kaynakMiktari = 0; // Kaynak miktarını sıfırla
        } else {
            // Kaynak miktarı sıfırsa farklı mesaj oluştur
            System.out.println(isim + " gezegeninde kaynak kalmadı.");
            for (int i = 0; i < mesaj.length(); i++) {
                System.out.print(mesaj.charAt(i)); // Harf harf yazdır
            }
            System.out.println(); // Yeni satıra geç
        }
    }

    // Gezegen bilgilerini gösteren metot
    @Override
    public void bilgiGoster() {
        // Gezegen bilgilerini döngüyle yazdır
        System.out.println("\n Gezegen: " + isim + ", Kaynak Miktarı: " + kaynakMiktari);
        for (int i = 0; i < bilgi.length(); i++) {
            System.out.print(bilgi.charAt(i)); // Harf harf yazdır
        }
        System.out.println(); // Yeni satıra geç
    }*/


